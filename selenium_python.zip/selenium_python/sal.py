
# Python program to demonstrate
# selenium
 
"""
from selenium import webdriver
from selenium.webdriver.firefox.options import Options

options = Options()
options.headless = True
driver = webdriver.Firefox(options=options)
driver.get("https://www.youtube.com/watch?v=wRn0pMLbVUE")
"""

from selenium import webdriver
driver = webdriver.Firefox()
driver.get('https://www.youtube.com/watch?v=2SYvhWMGvBo')
print(driver.title)
driver.quit()
